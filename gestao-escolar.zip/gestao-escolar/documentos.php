<?php
require_once 'conexao.php'; verificarLogin();
$c=conectar(); $id=(int)$_SESSION['usuario_id']; $msg=''; $tmsg='';

// Upload de documento
if ($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['acao']??'')==='upload') {
    $titulo=$c->real_escape_string(trim($_POST['titulo']??''));
    $desc=$c->real_escape_string(trim($_POST['descricao']??''));
    $turma=$c->real_escape_string(trim($_POST['turma']??''));
    $vis=$c->real_escape_string($_POST['visivel_para']??'todos');
    $dest=($_POST['destinatario_id']??0)?(int)$_POST['destinatario_id']:0;

    if (!empty($_FILES['arquivo']['name'])&&$titulo) {
        $ext=strtolower(pathinfo($_FILES['arquivo']['name'],PATHINFO_EXTENSION));
        $permitidos=['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','png','jpg','jpeg','zip'];
        if (in_array($ext,$permitidos)&&$_FILES['arquivo']['size']<10*1024*1024) {
            $fname='doc_'.$id.'_'.time().'.'.$ext;
            $dest_path=__DIR__.'/uploads/documentos/'.$fname;
            if (move_uploaded_file($_FILES['arquivo']['tmp_name'],$dest_path)) {
                $tam=(int)$_FILES['arquivo']['size']; $tipo=$c->real_escape_string($ext);
                $dest_sql=$dest?",$dest":",NULL";
                $c->query("INSERT INTO documentos(titulo,descricao,arquivo,tipo_arquivo,tamanho,turma,enviado_por,destinatario_id,visivel_para)VALUES('$titulo','$desc','$fname','$tipo',$tam,'$turma',$id".($dest?",".$dest:",NULL").",'$vis')");
                $msg='📁 Documento enviado!';$tmsg='sucesso';
            }
        } else { $msg='Arquivo inválido. Máx 10MB.';$tmsg='erro'; }
    } else { $msg='Preencha o título e selecione um arquivo.';$tmsg='erro'; }
}

// Excluir
if (isset($_GET['excluir'])) {
    $did=(int)$_GET['excluir'];
    $r=$c->query("SELECT * FROM documentos WHERE id=$did LIMIT 1");
    if ($r&&($d=$r->fetch_assoc())) {
        if ($d['enviado_por']==$id||ehAdmin()) {
            @unlink(__DIR__.'/uploads/documentos/'.$d['arquivo']);
            $c->query("DELETE FROM documentos WHERE id=$did");
            $msg='Documento removido.';$tmsg='sucesso';
        }
    }
}

// Listar documentos visíveis para o usuário
if (ehAdmin()) {
    $docs=$c->query("SELECT d.*,u.nome as enviado_nome,u2.nome as dest_nome FROM documentos d LEFT JOIN usuarios u ON d.enviado_por=u.id LEFT JOIN usuarios u2 ON d.destinatario_id=u2.id ORDER BY d.criado_em DESC");
} elseif (ehProfessor()) {
    $docs=$c->query("SELECT d.*,u.nome as enviado_nome,u2.nome as dest_nome FROM documentos d LEFT JOIN usuarios u ON d.enviado_por=u.id LEFT JOIN usuarios u2 ON d.destinatario_id=u2.id WHERE d.visivel_para IN('todos','professor') OR d.enviado_por=$id OR d.destinatario_id=$id ORDER BY d.criado_em DESC");
} else {
    $docs=$c->query("SELECT d.*,u.nome as enviado_nome,u2.nome as dest_nome FROM documentos d LEFT JOIN usuarios u ON d.enviado_por=u.id LEFT JOIN usuarios u2 ON d.destinatario_id=u2.id WHERE d.visivel_para='todos' OR d.destinatario_id=$id OR d.enviado_por=$id ORDER BY d.criado_em DESC");
}

// Buscar professores para envio direto (alunos enviam para professor)
$professores=$c->query("SELECT id,nome FROM usuarios WHERE tipo IN('professor','administrador') AND id!=$id ORDER BY nome");
$c->close(); $titulo_pagina='Documentos'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>

<div class="pagina-header">
    <div><h1>📁 Documentos</h1><p>Envie e baixe materiais e arquivos.</p></div>
    <button class="btn btn-primario" onclick="toggleForm('form-doc')">+ Enviar Documento</button>
</div>
<?php if($msg):?><div class="alerta alerta-<?=$tmsg?>"><?=htmlspecialchars($msg)?></div><?php endif;?>

<div id="form-doc" class="form-painel">
    <h2>➕ Enviar Documento</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="acao" value="upload">
        <div class="form-linha">
            <div class="campo-grupo"><label>Título</label><input type="text" name="titulo" required placeholder="Nome do documento"></div>
            <div class="campo-grupo"><label>Turma (opcional)</label><input type="text" name="turma" placeholder="Ex: 3º Ano A"></div>
        </div>
        <div class="campo-grupo"><label>Descrição (opcional)</label><textarea name="descricao" rows="2" placeholder="Descreva o documento..."></textarea></div>
        <div class="form-linha">
            <?php if(!ehAluno()):?>
            <div class="campo-grupo"><label>Visível para</label>
                <select name="visivel_para">
                    <option value="todos">Todos</option>
                    <option value="turma">Apenas a turma</option>
                    <option value="professor">Apenas professores</option>
                </select>
            </div><?php endif;?>
            <?php if(ehAluno()&&$professores&&$professores->num_rows>0):?>
            <div class="campo-grupo"><label>Enviar para</label>
                <select name="destinatario_id">
                    <option value="">Selecione o professor</option>
                    <?php while($p=$professores->fetch_assoc()):?>
                        <option value="<?=$p['id']?>"><?=htmlspecialchars($p['nome'])?></option>
                    <?php endwhile;?>
                </select>
            </div><?php endif;?>
        </div>
        <div class="campo-grupo">
            <label>Arquivo (máx. 10MB)</label>
            <input type="file" name="arquivo" required accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.png,.jpg,.jpeg,.zip">
            <small style="color:var(--texto-sub);font-size:0.8rem;margin-top:4px;display:block">PDF, Word, Excel, PowerPoint, imagens, ZIP</small>
        </div>
        <button type="submit" class="btn btn-primario">Enviar Documento 📤</button>
    </form>
</div>

<div class="lista-itens">
<?php
$icones=['pdf'=>'📄','doc'=>'📝','docx'=>'📝','xls'=>'📊','xlsx'=>'📊','ppt'=>'📊','pptx'=>'📊','txt'=>'📄','png'=>'🖼️','jpg'=>'🖼️','jpeg'=>'🖼️','zip'=>'🗜️'];
if($docs&&$docs->num_rows>0): while($d=$docs->fetch_assoc()):
    $ico=$icones[$d['tipo_arquivo']]??'📁';
    $tam=$d['tamanho']>1048576?round($d['tamanho']/1048576,1).'MB':round($d['tamanho']/1024,0).'KB';
?>
    <div class="item-card doc-card">
        <div class="item-card-header">
            <div class="doc-info">
                <span class="doc-icone"><?=$ico?></span>
                <div>
                    <h3><?=htmlspecialchars($d['titulo'])?></h3>
                    <?php if($d['descricao']):?><p><?=htmlspecialchars($d['descricao'])?></p><?php endif;?>
                </div>
            </div>
            <div style="text-align:right">
                <?php if($d['turma']):?><span class="badge-turma"><?=htmlspecialchars($d['turma'])?></span><?php endif;?>
                <span class="item-data" style="display:block;margin-top:4px"><?=date('d/m/Y',strtotime($d['criado_em']))?></span>
            </div>
        </div>
        <div class="item-card-footer">
            <div>
                <span class="item-autor">Por: <?=htmlspecialchars($d['enviado_nome']??'')?></span>
                <?php if($d['dest_nome']):?><span class="item-autor">Para: <?=htmlspecialchars($d['dest_nome'])?></span><?php endif;?>
                <span class="item-autor"><?=strtoupper($d['tipo_arquivo'])?> · <?=$tam?></span>
            </div>
            <div class="item-acoes">
                <a href="<?=SITE_URL?>/uploads/documentos/<?=htmlspecialchars($d['arquivo'])?>" class="btn-acao btn-editar" download>⬇️ Baixar</a>
                <?php if($d['enviado_por']==$id||ehAdmin()):?><a href="?excluir=<?=$d['id']?>" class="btn-acao btn-excluir" onclick="return confirm('Excluir?')">🗑️</a><?php endif;?>
            </div>
        </div>
    </div>
<?php endwhile; else:?><div class="estado-vazio"><span>📁</span><p>Nenhum documento disponível.</p></div><?php endif;?>
</div>

</main></div>
<?php include 'includes/footer.php'; ?>
