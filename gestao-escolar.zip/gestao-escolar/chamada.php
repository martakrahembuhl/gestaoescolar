<?php
require_once 'conexao.php'; verificarLogin();
$c=conectar(); $id=(int)$_SESSION['usuario_id']; $msg=''; $tmsg='';

// Salvar chamada
if ($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['acao']??'')==='salvar') {
    verificarTipo(['professor','administrador']);
    $turma=$c->real_escape_string(trim($_POST['turma']??''));
    $data=$c->real_escape_string($_POST['data_aula']??date('Y-m-d'));
    $mat=$c->real_escape_string(trim($_POST['materia']??''));
    $alunos=$_POST['alunos']??[]; $status=$_POST['status']??[]; $obs=$_POST['obs']??[];
    if ($turma&&!empty($alunos)) {
        $ck=$c->query("SELECT id FROM chamadas WHERE turma='$turma' AND data_aula='$data' AND professor_id=$id");
        if ($ck&&$ck->num_rows>0) { $msg='Já existe chamada desta turma nessa data!';$tmsg='erro'; }
        else {
            $c->query("INSERT INTO chamadas(turma,data_aula,materia,professor_id)VALUES('$turma','$data','$mat',$id)");
            $cid=$c->insert_id;
            foreach($alunos as $i=>$nome) {
                $n=$c->real_escape_string(trim($nome)); $s=$c->real_escape_string($status[$i]??'presente'); $o=$c->real_escape_string(trim($obs[$i]??''));
                if($n) $c->query("INSERT INTO presencas(chamada_id,aluno_nome,status,observacao)VALUES($cid,'$n','$s','$o')");
            }
            $msg='✅ Chamada registrada!';$tmsg='sucesso';
        }
    } else { $msg='Preencha a turma e adicione alunos.';$tmsg='erro'; }
}

// Excluir
if (isset($_GET['excluir'])&&(ehProfessor()||ehAdmin())) { $c->query("DELETE FROM chamadas WHERE id=".(int)$_GET['excluir']); $msg='Chamada removida.';$tmsg='sucesso'; }

// Ver detalhes
$detalhe=null; $presencas=[];
if (isset($_GET['ver'])) {
    $vid=(int)$_GET['ver'];
    $r=$c->query("SELECT ch.*,u.nome as prof_nome FROM chamadas ch LEFT JOIN usuarios u ON ch.professor_id=u.id WHERE ch.id=$vid LIMIT 1");
    if($r) $detalhe=$r->fetch_assoc();
    $r2=$c->query("SELECT * FROM presencas WHERE chamada_id=$vid ORDER BY aluno_nome");
    if($r2) while($p=$r2->fetch_assoc()) $presencas[]=$p;
}

// Listar
$where=ehAdmin()?'':'WHERE c.professor_id='.$id;
$chamadas=$c->query("SELECT c.*,u.nome as prof_nome,(SELECT COUNT(*) FROM presencas p WHERE p.chamada_id=c.id) as total,(SELECT COUNT(*) FROM presencas p WHERE p.chamada_id=c.id AND p.status='falta') as faltas FROM chamadas c LEFT JOIN usuarios u ON c.professor_id=u.id $where ORDER BY c.data_aula DESC");
$c->close(); $titulo_pagina='Chamada'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>

<div class="pagina-header">
    <div><h1>✅ Lista de Chamada</h1><p>Registre e consulte a presença dos alunos.</p></div>
    <?php if(ehProfessor()||ehAdmin()):?><button class="btn btn-primario" onclick="toggleForm('form-chamada')">+ Nova Chamada</button><?php endif;?>
</div>
<?php if($msg):?><div class="alerta alerta-<?=$tmsg?>"><?=htmlspecialchars($msg)?></div><?php endif;?>

<?php if(ehProfessor()||ehAdmin()):?>
<div id="form-chamada" class="form-painel">
    <h2>➕ Registrar Chamada</h2>
    <form method="POST" id="fch">
        <input type="hidden" name="acao" value="salvar">
        <div class="form-linha">
            <div class="campo-grupo"><label>Turma</label><input type="text" name="turma" required placeholder="Ex: 3º Ano A"></div>
            <div class="campo-grupo"><label>Data da Aula</label><input type="date" name="data_aula" required value="<?=date('Y-m-d')?>"></div>
        </div>
        <div class="campo-grupo campo-pequeno"><label>Matéria</label><input type="text" name="materia" placeholder="Ex: Matemática"></div>

        <div class="chamada-alunos">
            <div class="chamada-alunos-header">
                <h3>Alunos</h3>
                <button type="button" class="btn btn-primario btn-pequeno" onclick="adicionarAluno()">+ Adicionar Aluno</button>
            </div>
            <div id="lista-alunos">
                <div class="aluno-row">
                    <input type="text" name="alunos[]" placeholder="Nome do aluno" required>
                    <select name="status[]">
                        <option value="presente">✅ Presente</option>
                        <option value="falta">❌ Falta</option>
                        <option value="justificado">⚠️ Justificado</option>
                    </select>
                    <input type="text" name="obs[]" placeholder="Observação (opcional)">
                    <button type="button" class="btn-remover" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primario" style="margin-top:20px">Salvar Chamada</button>
    </form>
</div><?php endif;?>

<?php if($detalhe):?>
<div class="form-painel aberto">
    <div class="chamada-detalhe-header">
        <div>
            <h2>📋 Chamada — <?=htmlspecialchars($detalhe['turma'])?></h2>
            <p><?=date('d/m/Y',strtotime($detalhe['data_aula']))?> <?=$detalhe['materia']?'— '.$detalhe['materia']:''?> | Prof: <?=htmlspecialchars($detalhe['prof_nome']??'')?></p>
        </div>
        <a href="chamada.php" class="btn btn-outline" style="color:var(--texto)">← Voltar</a>
    </div>
    <div class="tabela-wrapper">
        <table class="tabela-chamada">
            <thead><tr><th>#</th><th>Aluno</th><th>Status</th><th>Observação</th></tr></thead>
            <tbody>
            <?php foreach($presencas as $i=>$p):?>
                <tr>
                    <td><?=$i+1?></td>
                    <td><?=htmlspecialchars($p['aluno_nome'])?></td>
                    <td><span class="badge-status badge-<?=$p['status']?>"><?=$p['status']==='presente'?'✅ Presente':($p['status']==='falta'?'❌ Falta':'⚠️ Justificado')?></span></td>
                    <td><?=htmlspecialchars($p['observacao']??'')?></td>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>
    </div>
    <?php
    $tot=count($presencas);
    $pres=count(array_filter($presencas,fn($p)=>$p['status']==='presente'));
    $falt=count(array_filter($presencas,fn($p)=>$p['status']==='falta'));
    $just=count(array_filter($presencas,fn($p)=>$p['status']==='justificado'));
    ?>
    <div class="chamada-resumo">
        <span>Total: <strong><?=$tot?></strong></span>
        <span class="pres">Presentes: <strong><?=$pres?></strong></span>
        <span class="falt">Faltas: <strong><?=$falt?></strong></span>
        <span class="just">Justificados: <strong><?=$just?></strong></span>
    </div>
</div>
<?php endif;?>

<div class="lista-itens">
<?php if($chamadas&&$chamadas->num_rows>0): while($ch=$chamadas->fetch_assoc()):?>
    <div class="item-card">
        <div class="item-card-header">
            <div><h3><?=htmlspecialchars($ch['turma'])?> <?=$ch['materia']?'<span class="badge-turma">'.htmlspecialchars($ch['materia']).'</span>':''?></h3>
            <span class="item-autor">Prof: <?=htmlspecialchars($ch['prof_nome']??'')?></span></div>
            <span class="item-data"><?=date('d/m/Y',strtotime($ch['data_aula']))?></span>
        </div>
        <div class="chamada-mini-stats">
            <span>👥 <?=$ch['total']?> alunos</span>
            <span class="falt">❌ <?=$ch['faltas']?> faltas</span>
            <span class="pres">✅ <?=$ch['total']-$ch['faltas']?> presentes</span>
        </div>
        <div class="item-card-footer">
            <a href="?ver=<?=$ch['id']?>" class="btn-acao btn-editar">👁️ Ver detalhes</a>
            <?php if(ehProfessor()||ehAdmin()):?><a href="?excluir=<?=$ch['id']?>" class="btn-acao btn-excluir" onclick="return confirm('Excluir?')">🗑️ Excluir</a><?php endif;?>
        </div>
    </div>
<?php endwhile; else:?><div class="estado-vazio"><span>✅</span><p>Nenhuma chamada registrada.</p></div><?php endif;?>
</div>

</main></div>
<script>
function adicionarAluno() {
    const div = document.createElement('div');
    div.className = 'aluno-row';
    div.innerHTML = `<input type="text" name="alunos[]" placeholder="Nome do aluno" required>
        <select name="status[]"><option value="presente">✅ Presente</option><option value="falta">❌ Falta</option><option value="justificado">⚠️ Justificado</option></select>
        <input type="text" name="obs[]" placeholder="Observação (opcional)">
        <button type="button" class="btn-remover" onclick="this.parentElement.remove()">✕</button>`;
    document.getElementById('lista-alunos').appendChild(div);
}
</script>
<?php include 'includes/footer.php'; ?>
