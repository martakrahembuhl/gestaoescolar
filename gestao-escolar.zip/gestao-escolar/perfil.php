<?php
require_once 'conexao.php'; verificarLogin();
$c=conectar(); $id=(int)$_SESSION['usuario_id']; $msg=''; $tmsg='';
$r=$c->query("SELECT * FROM usuarios WHERE id=$id LIMIT 1"); $perfil=$r->fetch_assoc();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $nome=$c->real_escape_string(trim($_POST['nome']??'')); $bio=$c->real_escape_string(trim($_POST['bio']??'')); $tel=$c->real_escape_string(trim($_POST['telefone']??'')); $foto=$perfil['foto']??'';
    if (!empty($_FILES['foto']['name'])) {
        $ext=strtolower(pathinfo($_FILES['foto']['name'],PATHINFO_EXTENSION));
        if (in_array($ext,['jpg','jpeg','png','webp'])&&$_FILES['foto']['size']<2*1024*1024) {
            $fn='foto_'.$id.'_'.time().'.'.$ext; $dest=__DIR__.'/uploads/fotos/'.$fn;
            if (move_uploaded_file($_FILES['foto']['tmp_name'],$dest)) { if($perfil['foto']&&file_exists(__DIR__.'/uploads/fotos/'.$perfil['foto']))@unlink(__DIR__.'/uploads/fotos/'.$perfil['foto']); $foto=$fn; }
        } else { $msg='Foto inválida. JPG/PNG/WEBP, máx 2MB.';$tmsg='erro'; }
    }
    if (!$msg) {
        $fs=$c->real_escape_string($foto);
        $c->query("UPDATE usuarios SET nome='$nome',bio='$bio',telefone='$tel',foto='$fs' WHERE id=$id");
        $_SESSION['usuario_nome']=$nome; $_SESSION['usuario_foto']=$foto;
        $msg='Perfil atualizado!';$tmsg='sucesso';
        $r=$c->query("SELECT * FROM usuarios WHERE id=$id LIMIT 1"); $perfil=$r->fetch_assoc();
    }
}
$c->close(); $titulo_pagina='Meu Perfil'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>
<div class="pagina-header"><div><h1>👤 Meu Perfil</h1><p>Gerencie suas informações pessoais</p></div></div>
<?php if($msg):?><div class="alerta alerta-<?=$tmsg?>"><?=htmlspecialchars($msg)?></div><?php endif;?>
<div class="perfil-grid">
    <div class="perfil-card">
        <div class="perfil-foto-grande">
            <?php if($perfil['foto']):?><img src="<?=SITE_URL?>/uploads/fotos/<?=htmlspecialchars($perfil['foto'])?>" alt=""><?php else:?><div class="perfil-inicial-grande"><?=strtoupper(substr($perfil['nome'],0,1))?></div><?php endif;?>
        </div>
        <h2><?=htmlspecialchars($perfil['nome'])?></h2>
        <span class="badge-tipo badge-<?=$perfil['tipo']?>"><?=ucfirst($perfil['tipo'])?></span>
        <div class="perfil-info-lista">
            <div class="perfil-info-item"><span>✉️</span><p><?=htmlspecialchars($perfil['email'])?></p></div>
            <?php if($perfil['telefone']):?><div class="perfil-info-item"><span>📞</span><p><?=htmlspecialchars($perfil['telefone'])?></p></div><?php endif;?>
            <?php if($perfil['bio']):?><div class="perfil-info-item"><span>📝</span><p><?=htmlspecialchars($perfil['bio'])?></p></div><?php endif;?>
            <div class="perfil-info-item"><span>📅</span><p>Membro desde <?=date('d/m/Y',strtotime($perfil['criado_em']))?></p></div>
        </div>
    </div>
    <div class="perfil-form-area">
        <div class="form-painel aberto"><h2>✏️ Editar Informações</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="foto-upload-area">
                    <div class="foto-preview" id="fp">
                        <?php if($perfil['foto']):?><img src="<?=SITE_URL?>/uploads/fotos/<?=htmlspecialchars($perfil['foto'])?>"><?php else:?><div class="perfil-inicial-grande" style="width:72px;height:72px;font-size:1.5rem;margin:0"><?=strtoupper(substr($perfil['nome'],0,1))?></div><?php endif;?>
                    </div>
                    <div class="foto-upload-info">
                        <label for="foto" class="btn btn-primario btn-pequeno" style="cursor:pointer">📷 Alterar foto</label>
                        <input type="file" name="foto" id="foto" accept="image/*" style="display:none" onchange="prevFoto(this)">
                        <p>JPG, PNG ou WEBP — máx. 2MB</p>
                    </div>
                </div>
                <div class="campo-grupo"><label>Nome completo</label><input type="text" name="nome" required value="<?=htmlspecialchars($perfil['nome'])?>"></div>
                <div class="campo-grupo"><label>Telefone</label><input type="text" name="telefone" placeholder="(00) 00000-0000" value="<?=htmlspecialchars($perfil['telefone']??'')?>"></div>
                <div class="campo-grupo"><label>Bio / Apresentação</label><textarea name="bio" rows="4" placeholder="Escreva algo sobre você..."><?=htmlspecialchars($perfil['bio']??'')?></textarea></div>
                <button type="submit" class="btn btn-primario">Salvar alterações</button>
            </form>
        </div>
    </div>
</div>
</main></div>
<script>function prevFoto(i){if(i.files&&i.files[0]){const r=new FileReader();r.onload=e=>{document.getElementById('fp').innerHTML=`<img src="${e.target.result}">`};r.readAsDataURL(i.files[0]);}}</script>
<?php include 'includes/footer.php'; ?>
