<?php
require_once 'conexao.php'; verificarLogin();
$c=conectar(); $msg=''; $tmsg='';
if ($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['acao'])&&$_POST['acao']==='cadastrar') {
    verificarTipo(['professor','administrador']);
    $t=$c->real_escape_string(trim($_POST['titulo']??'')); $d=$c->real_escape_string(trim($_POST['descricao']??''));
    $p=$c->real_escape_string($_POST['prazo']??''); $tu=$c->real_escape_string(trim($_POST['turma']??'')); $pid=(int)$_SESSION['usuario_id'];
    if($t&&$d&&$p&&$tu){$c->query("INSERT INTO atividades(titulo,descricao,prazo,turma,professor_id)VALUES('$t','$d','$p','$tu',$pid)");$msg='Atividade cadastrada!';$tmsg='sucesso';}
    else{$msg='Preencha todos os campos.';$tmsg='erro';}
}
if (isset($_GET['excluir'])&&(ehProfessor()||ehAdmin())) { $c->query("DELETE FROM atividades WHERE id=".(int)$_GET['excluir']); $msg='Removida.';$tmsg='sucesso'; }
$ft=$c->real_escape_string($_GET['turma']??''); $where=$ft?"WHERE a.turma='$ft'":'';
$atividades=$c->query("SELECT a.*,u.nome as prof_nome FROM atividades a LEFT JOIN usuarios u ON a.professor_id=u.id $where ORDER BY a.prazo ASC");
$turmas=$c->query("SELECT DISTINCT turma FROM atividades ORDER BY turma");
$c->close(); $titulo_pagina='Atividades'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>
<div class="pagina-header">
    <div><h1>📋 Atividades</h1><p>Tarefas e prazos por turma.</p></div>
    <?php if(ehProfessor()||ehAdmin()):?><button class="btn btn-primario" onclick="toggleForm('form-atv')">+ Nova Atividade</button><?php endif;?>
</div>
<?php if($msg):?><div class="alerta alerta-<?=$tmsg?>"><?=htmlspecialchars($msg)?></div><?php endif;?>
<?php if(ehProfessor()||ehAdmin()):?>
<div id="form-atv" class="form-painel">
    <h2>➕ Nova Atividade</h2>
    <form method="POST"><input type="hidden" name="acao" value="cadastrar">
        <div class="form-linha">
            <div class="campo-grupo"><label>Título</label><input type="text" name="titulo" required></div>
            <div class="campo-grupo"><label>Turma</label><input type="text" name="turma" required placeholder="Ex: 3º Ano A"></div>
        </div>
        <div class="campo-grupo"><label>Descrição</label><textarea name="descricao" rows="3" required></textarea></div>
        <div class="campo-grupo campo-pequeno"><label>Prazo</label><input type="date" name="prazo" required min="<?=date('Y-m-d')?>"></div>
        <button type="submit" class="btn btn-primario">Cadastrar</button>
    </form>
</div><?php endif;?>
<?php if($turmas&&$turmas->num_rows>0):?>
<div class="filtros"><a href="atividades.php" class="filtro-btn <?=!$ft?'ativo':''?>">Todas</a>
<?php while($t=$turmas->fetch_assoc()):?><a href="?turma=<?=urlencode($t['turma'])?>" class="filtro-btn <?=$ft===$t['turma']?'ativo':''?>"><?=htmlspecialchars($t['turma'])?></a><?php endwhile;?>
</div><?php endif;?>
<div class="lista-itens">
<?php if($atividades&&$atividades->num_rows>0): while($a=$atividades->fetch_assoc()):
    $pd=new DateTime($a['prazo']); $hj=new DateTime(); $df=$hj->diff($pd)->days; $at=$pd<$hj; $urg=!$at&&$df<=3;?>
    <div class="item-card <?=$at?'card-atrasado':($urg?'card-urgente':'')?>">
        <div class="item-card-header"><h3><?=htmlspecialchars($a['titulo'])?></h3><span class="badge-turma"><?=htmlspecialchars($a['turma'])?></span></div>
        <p><?=nl2br(htmlspecialchars($a['descricao']))?></p>
        <div class="item-card-footer">
            <div><span class="item-data prazo <?=$at?'atrasado':($urg?'urgente':'')?>">⏰ <?=date('d/m/Y',strtotime($a['prazo']))?><?=$at?' — Atrasado!':($urg?" — $df dia(s)!":'')?></span><span class="item-autor">Prof: <?=htmlspecialchars($a['prof_nome']??'N/A')?></span></div>
            <?php if(ehProfessor()||ehAdmin()):?><a href="?excluir=<?=$a['id']?>" class="btn-acao btn-excluir" onclick="return confirm('Remover?')">🗑️ Remover</a><?php endif;?>
        </div>
    </div>
<?php endwhile; else:?><div class="estado-vazio"><span>📋</span><p>Nenhuma atividade.</p></div><?php endif;?>
</div>
</main></div>
<?php include 'includes/footer.php'; ?>
