-- =============================================
-- Banco de dados COMPLETO: Gestão Escolar
-- Inclui: usuários, avisos, atividades,
--         mensagens, chamada, documentos
-- =============================================

CREATE DATABASE IF NOT EXISTS gestao_escolar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestao_escolar;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor', 'administrador') DEFAULT 'aluno',
    bio TEXT,
    telefone VARCHAR(20),
    foto VARCHAR(255),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de avisos
CREATE TABLE IF NOT EXISTS avisos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    data_publicacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    autor_id INT,
    FOREIGN KEY (autor_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Tabela de atividades
CREATE TABLE IF NOT EXISTS atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    prazo DATE NOT NULL,
    turma VARCHAR(100) NOT NULL,
    professor_id INT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (professor_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Tabela de mensagens
CREATE TABLE IF NOT EXISTS mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    remetente_id INT NOT NULL,
    destinatario_id INT NOT NULL,
    mensagem TEXT NOT NULL,
    lida TINYINT(1) DEFAULT 0,
    enviado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (remetente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (destinatario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de chamadas
CREATE TABLE IF NOT EXISTS chamadas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    turma VARCHAR(100) NOT NULL,
    data_aula DATE NOT NULL,
    materia VARCHAR(100),
    professor_id INT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (professor_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Tabela de presenças
CREATE TABLE IF NOT EXISTS presencas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chamada_id INT NOT NULL,
    aluno_nome VARCHAR(100) NOT NULL,
    status ENUM('presente', 'falta', 'justificado') DEFAULT 'presente',
    observacao VARCHAR(255),
    FOREIGN KEY (chamada_id) REFERENCES chamadas(id) ON DELETE CASCADE
);

-- Tabela de documentos
CREATE TABLE IF NOT EXISTS documentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    arquivo VARCHAR(255) NOT NULL,
    tipo_arquivo VARCHAR(50),
    tamanho INT,
    turma VARCHAR(100),
    enviado_por INT,
    destinatario_id INT DEFAULT NULL,
    visivel_para ENUM('todos', 'turma', 'professor') DEFAULT 'todos',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (enviado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (destinatario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- =============================================
-- DADOS DE TESTE
-- =============================================

-- Usuários (senha: 123456)
INSERT INTO usuarios (nome, email, senha, tipo, bio, telefone) VALUES
('Administrador', 'admin@escola.com', MD5('123456'), 'administrador', 'Diretora da escola, responsável pela gestão pedagógica e administrativa.', '(47) 99999-0001'),
('Prof. Carlos', 'professor@escola.com', MD5('123456'), 'professor', 'Professor de Matemática e Física. 10 anos de experiência no ensino médio.', '(47) 99999-0002'),
('Ana Silva', 'aluno@escola.com', MD5('123456'), 'aluno', 'Aluna do 3º Ano A.', '(47) 99999-0003');

-- Avisos
INSERT INTO avisos (titulo, descricao, autor_id) VALUES
('Reunião de Pais e Mestres', 'A reunião será realizada no dia 20/03 às 19h no auditório. A presença é fundamental.', 1),
('Feriado — Sem Aulas', 'Na próxima segunda-feira não haverá aulas. As atividades retornam na terça normalmente.', 1);

-- Atividades
INSERT INTO atividades (titulo, descricao, prazo, turma, professor_id) VALUES
('Trabalho de Matemática', 'Resolver os exercícios 1 ao 10 da página 45 do livro didático.', '2026-03-25', '3º Ano A', 2),
('Redação — Meio Ambiente', 'Escrever uma redação dissertativa-argumentativa. Mínimo de 25 linhas.', '2026-03-28', '3º Ano B', 2);

-- Mensagens
INSERT INTO mensagens (remetente_id, destinatario_id, mensagem) VALUES
(1, 2, 'Prof. Carlos, poderia enviar o planejamento das próximas aulas até sexta-feira?'),
(2, 1, 'Claro, diretora! Enviarei até quinta no máximo.');
