<?php
require_once 'conexao.php';
if (isset($_SESSION['usuario_id'])) { header('Location: '.SITE_URL.'/dashboard.php'); exit; }
$erro = ''; $sucesso = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    $tipo  = $_POST['tipo'] ?? 'aluno';
    if (!$nome || !$email || !$senha) { $erro = 'Preencha todos os campos.'; }
    elseif (strlen($senha) < 6) { $erro = 'Senha mínimo 6 caracteres.'; }
    else {
        $c = conectar();
        $n = $c->real_escape_string($nome); $e = $c->real_escape_string($email);
        $t = $c->real_escape_string($tipo); $s = md5($senha);
        $ck = $c->query("SELECT id FROM usuarios WHERE email='$e'");
        if ($ck && $ck->num_rows > 0) { $erro = 'E-mail já cadastrado.'; }
        else {
            $c->query("INSERT INTO usuarios (nome,email,senha,tipo) VALUES ('$n','$e','$s','$t')");
            $sucesso = 'Conta criada! Faça login para continuar.';
        }
        $c->close();
    }
}
$titulo_pagina = 'Cadastro'; include 'includes/header.php'; ?>
<div class="auth-wrapper">
    <div class="auth-esquerda">
        <div class="auth-logo"><span>🎓</span><span>Gestão<strong>Escolar</strong></span></div>
        <h2>Crie sua conta</h2>
        <p>Junte-se à plataforma e acesse todos os recursos da escola.</p>
    </div>
    <div class="auth-direita">
        <div class="auth-caixa">
            <h1>Cadastro</h1>
            <p class="auth-sub">Preencha seus dados</p>
            <?php if ($erro): ?><div class="alerta alerta-erro">❌ <?= htmlspecialchars($erro) ?></div><?php endif; ?>
            <?php if ($sucesso): ?><div class="alerta alerta-sucesso">✅ <?= htmlspecialchars($sucesso) ?></div><?php endif; ?>
            <form method="POST">
                <div class="campo-grupo"><label>Nome completo</label><input type="text" name="nome" required placeholder="Seu nome" value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>"></div>
                <div class="campo-grupo"><label>E-mail</label><input type="email" name="email" required placeholder="seu@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div>
                <div class="campo-grupo"><label>Senha</label><input type="password" name="senha" required placeholder="Mínimo 6 caracteres" minlength="6"></div>
                <div class="campo-grupo"><label>Tipo</label>
                    <select name="tipo"><option value="aluno">Aluno</option><option value="professor">Professor</option></select>
                </div>
                <button type="submit" class="btn btn-primario btn-full">Criar conta</button>
            </form>
            <p class="auth-link">Já tem conta? <a href="login.php">Entrar</a></p>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
