<?php
define('DB_HOST',   'localhost');
define('DB_NOME',   'gestao_escolar_marta');
define('DB_USUARIO','root');
define('DB_SENHA',  '');
define('SITE_URL',  'http://localhost/gestao-escolar');

if (session_status() === PHP_SESSION_NONE) session_start();

function conectar() {
    $c = new mysqli(DB_HOST, DB_USUARIO, DB_SENHA, DB_NOME);
    if ($c->connect_error) die('<p style="font-family:sans-serif;color:red;padding:20px;">Erro BD: ' . $c->connect_error . '</p>');
    $c->set_charset('utf8mb4');
    return $c;
}

function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) { header('Location: ' . SITE_URL . '/login.php'); exit; }
}

function verificarTipo($tipos) {
    verificarLogin();
    if (!in_array($_SESSION['usuario_tipo'], (array)$tipos)) { header('Location: ' . SITE_URL . '/dashboard.php?erro=acesso'); exit; }
}

function ehAdmin()     { return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'administrador'; }
function ehProfessor() { return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'professor'; }
function ehAluno()     { return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'aluno'; }
function nomeUsuario() { return $_SESSION['usuario_nome'] ?? ''; }
function tipoUsuario() { return $_SESSION['usuario_tipo'] ?? ''; }
