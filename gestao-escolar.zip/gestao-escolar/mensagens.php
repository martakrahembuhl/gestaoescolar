<?php
require_once 'conexao.php'; verificarLogin();
$c=conectar(); $id=(int)$_SESSION['usuario_id'];
if ($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['mensagem'],$_POST['destinatario_id'])) {
    $did=(int)$_POST['destinatario_id']; $m=$c->real_escape_string(trim($_POST['mensagem']));
    if($m&&$did&&$did!==$id) $c->query("INSERT INTO mensagens(remetente_id,destinatario_id,mensagem)VALUES($id,$did,'$m')");
    header('Location: '.SITE_URL.'/mensagens.php?conversa='.$did); exit;
}
$cid=isset($_GET['conversa'])?(int)$_GET['conversa']:0;
if($cid) $c->query("UPDATE mensagens SET lida=1 WHERE remetente_id=$cid AND destinatario_id=$id AND lida=0");
$usuarios=$c->query("SELECT u.id,u.nome,u.tipo,u.foto,(SELECT COUNT(*) FROM mensagens m WHERE m.remetente_id=u.id AND m.destinatario_id=$id AND m.lida=0) as nl,(SELECT m2.mensagem FROM mensagens m2 WHERE(m2.remetente_id=u.id AND m2.destinatario_id=$id)OR(m2.remetente_id=$id AND m2.destinatario_id=u.id) ORDER BY m2.enviado_em DESC LIMIT 1) as um FROM usuarios u WHERE u.id!=$id ORDER BY um DESC,u.nome ASC");
$msgs_conv=[]; $cu=null;
if($cid){$r=$c->query("SELECT * FROM usuarios WHERE id=$cid LIMIT 1");if($r)$cu=$r->fetch_assoc();$r2=$c->query("SELECT m.*,u.nome as rn,u.foto as rf FROM mensagens m JOIN usuarios u ON m.remetente_id=u.id WHERE(m.remetente_id=$id AND m.destinatario_id=$cid)OR(m.remetente_id=$cid AND m.destinatario_id=$id) ORDER BY m.enviado_em ASC");while($m=$r2->fetch_assoc())$msgs_conv[]=$m;}
$c->close(); $titulo_pagina='Mensagens'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>
<div class="chat-layout">
    <div class="chat-lista">
        <div class="chat-lista-header"><h2>💬 Mensagens</h2></div>
        <div class="chat-contatos">
        <?php if($usuarios&&$usuarios->num_rows>0): while($u=$usuarios->fetch_assoc()):?>
            <a href="?conversa=<?=$u['id']?>" class="contato-item <?=$cid==$u['id']?'ativo':''?>">
                <div class="contato-avatar"><?php if($u['foto']):?><img src="<?=SITE_URL?>/uploads/fotos/<?=htmlspecialchars($u['foto'])?>"><?php else:?><span><?=strtoupper(substr($u['nome'],0,1))?></span><?php endif;?><?php if($u['nl']>0):?><span class="badge-nao-lidas"><?=$u['nl']?></span><?php endif;?></div>
                <div class="contato-info"><strong><?=htmlspecialchars($u['nome'])?></strong><span class="contato-tipo"><?=ucfirst($u['tipo'])?></span><?php if($u['um']):?><p><?=htmlspecialchars(substr($u['um'],0,35))?>...</p><?php endif;?></div>
            </a>
        <?php endwhile; else:?><p class="vazio" style="padding:20px">Nenhum usuário.</p><?php endif;?>
        </div>
    </div>
    <div class="chat-area">
        <?php if($cu):?>
        <div class="chat-header"><div class="chat-header-usuario">
            <div class="contato-avatar pequeno"><?php if($cu['foto']):?><img src="<?=SITE_URL?>/uploads/fotos/<?=htmlspecialchars($cu['foto'])?>"><?php else:?><span><?=strtoupper(substr($cu['nome'],0,1))?></span><?php endif;?></div>
            <div><strong><?=htmlspecialchars($cu['nome'])?></strong><span><?=ucfirst($cu['tipo'])?></span></div>
        </div></div>
        <div class="chat-mensagens" id="cm">
            <?php if(empty($msgs_conv)):?><div class="chat-vazio"><span>💬</span><p>Nenhuma mensagem ainda.</p></div>
            <?php else: foreach($msgs_conv as $m): $minha=$m['remetente_id']==$id;?>
                <div class="msg-wrapper <?=$minha?'msg-minha':'msg-deles'?>">
                    <?php if(!$minha):?><div class="msg-avatar"><?php if($m['rf']):?><img src="<?=SITE_URL?>/uploads/fotos/<?=htmlspecialchars($m['rf'])?>"><?php else:?><?=strtoupper(substr($m['rn'],0,1))?><?php endif;?></div><?php endif;?>
                    <div class="msg-balao"><p><?=nl2br(htmlspecialchars($m['mensagem']))?></p><span class="msg-hora"><?=date('H:i',strtotime($m['enviado_em']))?></span></div>
                </div>
            <?php endforeach; endif;?>
        </div>
        <form class="chat-input" method="POST">
            <input type="hidden" name="destinatario_id" value="<?=$cid?>">
            <textarea name="mensagem" placeholder="Digite sua mensagem..." rows="1" required onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.form.submit();}"></textarea>
            <button type="submit" class="btn btn-primario">Enviar ➤</button>
        </form>
        <?php else:?><div class="chat-vazio chat-vazio-central"><span>💬</span><p>Selecione uma conversa</p></div><?php endif;?>
    </div>
</div>
</main></div>
<script>const cm=document.getElementById('cm');if(cm)cm.scrollTop=cm.scrollHeight;</script>
<?php include 'includes/footer.php'; ?>
