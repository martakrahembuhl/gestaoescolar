<?php
require_once 'conexao.php'; verificarLogin();
$c = conectar(); $id = (int)$_SESSION['usuario_id'];
$t_avisos     = $c->query("SELECT COUNT(*) as t FROM avisos")->fetch_assoc()['t'];
$t_atividades = $c->query("SELECT COUNT(*) as t FROM atividades")->fetch_assoc()['t'];
$t_usuarios   = $c->query("SELECT COUNT(*) as t FROM usuarios")->fetch_assoc()['t'];
$t_chamadas   = $c->query("SELECT COUNT(*) as t FROM chamadas")->fetch_assoc()['t'];
$ult_avisos   = $c->query("SELECT * FROM avisos ORDER BY data_publicacao DESC LIMIT 3");
$prox_atv     = $c->query("SELECT * FROM atividades WHERE prazo >= CURDATE() ORDER BY prazo ASC LIMIT 3");
$c->close();
$titulo_pagina = 'Dashboard'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>

<div class="pagina-header">
    <div>
        <h1>Dashboard</h1>
        <p>Bem-vindo, <strong><?= htmlspecialchars(nomeUsuario()) ?></strong>!</p>
    </div>
</div>
<?php if (isset($_GET['erro']) && $_GET['erro']==='acesso'): ?><div class="alerta alerta-erro">❌ Sem permissão para acessar essa área.</div><?php endif; ?>

<div class="cards-resumo">
    <div class="resumo-card"><div class="resumo-icone icone-azul">📢</div><div><h3><?= $t_avisos ?></h3><p>Avisos</p></div></div>
    <div class="resumo-card"><div class="resumo-icone icone-verde">📋</div><div><h3><?= $t_atividades ?></h3><p>Atividades</p></div></div>
    <div class="resumo-card"><div class="resumo-icone icone-roxo">✅</div><div><h3><?= $t_chamadas ?></h3><p>Chamadas</p></div></div>
    <?php if (ehAdmin()): ?><div class="resumo-card"><div class="resumo-icone icone-azul">👥</div><div><h3><?= $t_usuarios ?></h3><p>Usuários</p></div></div><?php endif; ?>
</div>

<div class="dash-grid">
    <div class="dash-bloco">
        <div class="bloco-header"><h2>📢 Últimos Avisos</h2><a href="avisos.php">Ver todos →</a></div>
        <?php if ($ult_avisos && $ult_avisos->num_rows > 0): while ($a = $ult_avisos->fetch_assoc()): ?>
            <div class="item-lista"><strong><?= htmlspecialchars($a['titulo']) ?></strong><span class="item-data"><?= date('d/m/Y', strtotime($a['data_publicacao'])) ?></span></div>
        <?php endwhile; else: ?><p class="vazio">Nenhum aviso.</p><?php endif; ?>
    </div>
    <div class="dash-bloco">
        <div class="bloco-header"><h2>📋 Próximas Atividades</h2><a href="atividades.php">Ver todas →</a></div>
        <?php if ($prox_atv && $prox_atv->num_rows > 0): while ($a = $prox_atv->fetch_assoc()): ?>
            <div class="item-lista"><strong><?= htmlspecialchars($a['titulo']) ?></strong><p>Turma: <?= htmlspecialchars($a['turma']) ?></p><span class="item-data prazo">⏰ <?= date('d/m/Y', strtotime($a['prazo'])) ?></span></div>
        <?php endwhile; else: ?><p class="vazio">Nenhuma atividade.</p><?php endif; ?>
    </div>
</div>

</main></div>
<?php include 'includes/footer.php'; ?>
