function toggleForm(id) {
    const el = document.getElementById(id);
    if (el) el.classList.toggle('aberto');
}
