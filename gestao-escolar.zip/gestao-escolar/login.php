<?php
require_once 'conexao.php';
if (isset($_SESSION['usuario_id'])) { header('Location: '.SITE_URL.'/dashboard.php'); exit; }
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    if (!$email || !$senha) { $erro = 'Preencha todos os campos.'; }
    else {
        $c = conectar();
        $e = $c->real_escape_string($email);
        $s = md5($senha);
        $r = $c->query("SELECT * FROM usuarios WHERE email='$e' AND senha='$s' LIMIT 1");
        if ($r && $r->num_rows === 1) {
            $u = $r->fetch_assoc();
            $_SESSION['usuario_id']   = $u['id'];
            $_SESSION['usuario_nome'] = $u['nome'];
            $_SESSION['usuario_tipo'] = $u['tipo'];
            $_SESSION['usuario_foto'] = $u['foto'] ?? '';
            $c->close();
            header('Location: '.SITE_URL.'/dashboard.php'); exit;
        } else { $erro = 'E-mail ou senha incorretos.'; }
        $c->close();
    }
}
$titulo_pagina = 'Login'; include 'includes/header.php'; ?>
<div class="auth-wrapper">
    <div class="auth-esquerda">
        <div class="auth-logo"><span>🎓</span><span>Gestão<strong>Escolar</strong></span></div>
        <h2>Bem-vindo de volta!</h2>
        <p>Acesse sua conta para ver avisos, atividades, chamadas e muito mais.</p>
    </div>
    <div class="auth-direita">
        <div class="auth-caixa">
            <h1>Entrar</h1>
            <p class="auth-sub">Digite seus dados de acesso</p>
            <?php if ($erro): ?><div class="alerta alerta-erro">❌ <?= htmlspecialchars($erro) ?></div><?php endif; ?>
            <form method="POST">
                <div class="campo-grupo"><label>E-mail</label><input type="email" name="email" placeholder="seu@email.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div>
                <div class="campo-grupo"><label>Senha</label><input type="password" name="senha" placeholder="••••••••" required></div>
                <button type="submit" class="btn btn-primario btn-full">Entrar</button>
            </form>
            <p class="auth-link">Não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
            <div class="auth-dica">
                <p><strong>Contas de teste:</strong></p>
                <p>admin@escola.com — 123456 (Administrador)</p>
                <p>professor@escola.com — 123456 (Professor)</p>
                <p>aluno@escola.com — 123456 (Aluno)</p>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
