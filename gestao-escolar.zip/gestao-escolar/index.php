<?php require_once 'conexao.php';
if (isset($_SESSION['usuario_id'])) { header('Location: '.SITE_URL.'/dashboard.php'); exit; }
$titulo_pagina = 'Bem-vindo'; include 'includes/header.php'; ?>
<div class="pagina-publica">
    <div class="pub-esquerda">
        <div class="pub-conteudo">
            <div class="pub-logo"><span>🎓</span><span>Gestão<strong>Escolar</strong></span></div>
            <h1>Plataforma de<br>Gestão Escolar</h1>
            <p>Centralize avisos, atividades, chamadas e documentos da sua escola em um só lugar.</p>
            <div class="pub-botoes">
                <a href="login.php" class="btn btn-primario">Entrar no sistema</a>
                <a href="cadastro.php" class="btn btn-outline">Criar conta</a>
            </div>
        </div>
    </div>
    <div class="pub-direita">
        <div class="pub-cards-demo">
            <div class="demo-card"><span>📢</span><div><strong>Avisos</strong><p>Comunicados importantes</p></div></div>
            <div class="demo-card"><span>✅</span><div><strong>Chamada</strong><p>Controle de presença</p></div></div>
            <div class="demo-card"><span>📁</span><div><strong>Documentos</strong><p>Arquivos e materiais</p></div></div>
            <div class="demo-card"><span>💬</span><div><strong>Mensagens</strong><p>Chat entre usuários</p></div></div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
