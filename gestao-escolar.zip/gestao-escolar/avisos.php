<?php
require_once 'conexao.php'; verificarLogin();
$c = conectar(); $msg = ''; $tmsg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['acao'])) {
    if ($_POST['acao']==='cadastrar') { verificarTipo('administrador');
        $t=$c->real_escape_string(trim($_POST['titulo']??'')); $d=$c->real_escape_string(trim($_POST['descricao']??'')); $aid=(int)$_SESSION['usuario_id'];
        if($t&&$d){$c->query("INSERT INTO avisos(titulo,descricao,autor_id)VALUES('$t','$d',$aid)");$msg='Aviso publicado!';$tmsg='sucesso';}
        else{$msg='Preencha todos os campos.';$tmsg='erro';}
    } elseif ($_POST['acao']==='editar') { verificarTipo('administrador');
        $id=(int)$_POST['id']; $t=$c->real_escape_string(trim($_POST['titulo']??'')); $d=$c->real_escape_string(trim($_POST['descricao']??''));
        $c->query("UPDATE avisos SET titulo='$t',descricao='$d' WHERE id=$id"); $msg='Aviso atualizado!';$tmsg='sucesso';
    }
}
if (isset($_GET['excluir'])&&ehAdmin()) { $c->query("DELETE FROM avisos WHERE id=".(int)$_GET['excluir']); $msg='Aviso excluído.';$tmsg='sucesso'; }
$editando=null;
if (isset($_GET['editar'])&&ehAdmin()) { $r=$c->query("SELECT * FROM avisos WHERE id=".(int)$_GET['editar']." LIMIT 1"); if($r)$editando=$r->fetch_assoc(); }
$avisos=$c->query("SELECT a.*,u.nome as autor_nome FROM avisos a LEFT JOIN usuarios u ON a.autor_id=u.id ORDER BY a.data_publicacao DESC");
$c->close(); $titulo_pagina='Avisos'; include 'includes/header.php'; include 'includes/sidebar.php'; ?>
<div class="pagina-header">
    <div><h1>📢 Mural de Avisos</h1><p>Comunicados e informações importantes.</p></div>
    <?php if(ehAdmin()):?><button class="btn btn-primario" onclick="toggleForm('form-aviso')">+ Novo Aviso</button><?php endif;?>
</div>
<?php if($msg):?><div class="alerta alerta-<?=$tmsg?>"><?=htmlspecialchars($msg)?></div><?php endif;?>
<?php if(ehAdmin()):?>
<div id="form-aviso" class="form-painel <?=$editando?'aberto':''?>">
    <h2><?=$editando?'✏️ Editar':'➕ Novo'?> Aviso</h2>
    <form method="POST">
        <input type="hidden" name="acao" value="<?=$editando?'editar':'cadastrar'?>">
        <?php if($editando):?><input type="hidden" name="id" value="<?=$editando['id']?>"><?php endif;?>
        <div class="campo-grupo"><label>Título</label><input type="text" name="titulo" required value="<?=htmlspecialchars($editando['titulo']??'')?>"></div>
        <div class="campo-grupo"><label>Descrição</label><textarea name="descricao" rows="4" required><?=htmlspecialchars($editando['descricao']??'')?></textarea></div>
        <div class="form-botoes"><button type="submit" class="btn btn-primario"><?=$editando?'Salvar':'Publicar'?></button><?php if($editando):?><a href="avisos.php" class="btn btn-outline" style="color:var(--texto)">Cancelar</a><?php endif;?></div>
    </form>
</div><?php endif;?>
<div class="lista-itens">
<?php if($avisos&&$avisos->num_rows>0): while($a=$avisos->fetch_assoc()):?>
    <div class="item-card">
        <div class="item-card-header"><h3><?=htmlspecialchars($a['titulo'])?></h3><span class="item-data"><?=date('d/m/Y \à\s H:i',strtotime($a['data_publicacao']))?></span></div>
        <p><?=nl2br(htmlspecialchars($a['descricao']))?></p>
        <div class="item-card-footer">
            <span class="item-autor">Por: <?=htmlspecialchars($a['autor_nome']??'Sistema')?></span>
            <?php if(ehAdmin()):?><div class="item-acoes"><a href="?editar=<?=$a['id']?>" class="btn-acao btn-editar">✏️ Editar</a><a href="?excluir=<?=$a['id']?>" class="btn-acao btn-excluir" onclick="return confirm('Excluir?')">🗑️ Excluir</a></div><?php endif;?>
        </div>
    </div>
<?php endwhile; else:?><div class="estado-vazio"><span>📢</span><p>Nenhum aviso publicado.</p></div><?php endif;?>
</div>
</main></div>
<?php include 'includes/footer.php'; ?>
