<script src="<?= SITE_URL ?>/css/script.js"></script>
</body>
</html>
