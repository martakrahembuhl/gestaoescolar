<?php
$pagina_atual = basename($_SERVER['PHP_SELF'], '.php');
$nao_lidas = 0;
if (isset($_SESSION['usuario_id'])) {
    $ct = conectar();
    $id = (int)$_SESSION['usuario_id'];
    $r  = $ct->query("SELECT COUNT(*) as t FROM mensagens WHERE destinatario_id=$id AND lida=0");
    if ($r) $nao_lidas = $r->fetch_assoc()['t'];
    $ct->close();
}
?>
<div class="layout">
<aside class="sidebar">
    <div class="sidebar-logo">
        <span class="logo-icone">🎓</span>
        <span>Gestão<strong>Escolar</strong></span>
    </div>

    <a href="<?= SITE_URL ?>/perfil.php" class="sidebar-usuario">
        <div class="avatar">
            <?php if (!empty($_SESSION['usuario_foto'])): ?>
                <img src="<?= SITE_URL ?>/uploads/fotos/<?= htmlspecialchars($_SESSION['usuario_foto']) ?>">
            <?php else: ?>
                <?= strtoupper(substr(nomeUsuario(), 0, 1)) ?>
            <?php endif; ?>
        </div>
        <div>
            <p class="usuario-nome"><?= htmlspecialchars(nomeUsuario()) ?></p>
            <span class="badge-tipo badge-<?= tipoUsuario() ?>"><?= ucfirst(tipoUsuario()) ?></span>
        </div>
    </a>

    <nav class="sidebar-nav">
        <a href="<?= SITE_URL ?>/dashboard.php"   class="<?= $pagina_atual==='dashboard'  ?'ativo':'' ?>"><span>⊞</span> Dashboard</a>
        <a href="<?= SITE_URL ?>/avisos.php"       class="<?= $pagina_atual==='avisos'     ?'ativo':'' ?>"><span>📢</span> Avisos</a>
        <a href="<?= SITE_URL ?>/atividades.php"   class="<?= $pagina_atual==='atividades' ?'ativo':'' ?>"><span>📋</span> Atividades</a>
        <a href="<?= SITE_URL ?>/chamada.php"      class="<?= $pagina_atual==='chamada'    ?'ativo':'' ?>"><span>✅</span> Chamada</a>
        <a href="<?= SITE_URL ?>/documentos.php"   class="<?= $pagina_atual==='documentos' ?'ativo':'' ?>"><span>📁</span> Documentos</a>
        <a href="<?= SITE_URL ?>/mensagens.php"    class="<?= $pagina_atual==='mensagens'  ?'ativo':'' ?>">
            <span>💬</span> Mensagens
            <?php if ($nao_lidas > 0): ?><span class="nav-badge"><?= $nao_lidas ?></span><?php endif; ?>
        </a>
        <a href="<?= SITE_URL ?>/perfil.php"       class="<?= $pagina_atual==='perfil'     ?'ativo':'' ?>"><span>👤</span> Meu Perfil</a>
        <?php if (ehAdmin()): ?>
        <a href="<?= SITE_URL ?>/cadastro.php"     class="<?= $pagina_atual==='cadastro'   ?'ativo':'' ?>"><span>👥</span> Usuários</a>
        <?php endif; ?>
    </nav>

    <a href="<?= SITE_URL ?>/logout.php" class="sidebar-logout"><span>⏻</span> Sair</a>
</aside>
<main class="conteudo">
